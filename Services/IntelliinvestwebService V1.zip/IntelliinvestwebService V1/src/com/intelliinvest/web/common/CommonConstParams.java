package com.intelliinvest.web.common;

import java.text.SimpleDateFormat;

public interface CommonConstParams {

	String ERROR_MSG_DEFAULT = "Invalid Input Value, Please check...";
	SimpleDateFormat userDateFormat = new SimpleDateFormat("dd/MM/yyyy");
}
