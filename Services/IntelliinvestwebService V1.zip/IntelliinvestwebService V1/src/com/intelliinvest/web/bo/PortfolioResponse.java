package com.intelliinvest.web.bo;

import java.util.List;

import com.intelliinvest.data.model.ManagePortfolioData;
import com.intelliinvest.web.dao.ManagePortfolioDao;

public class PortfolioResponse {

	private List<ManagePortfolioData> managePortfolioDatas;
	private String userId;
	private boolean success;
	private String message;
	
	public PortfolioResponse() {
		super();
	}

	public PortfolioResponse(List<ManagePortfolioData> managePortfolioDatas,
			boolean success, String message) {
		super();
		this.managePortfolioDatas = managePortfolioDatas;
		this.success = success;
		this.message = message;
	}
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<ManagePortfolioData> getManagePortfolioDatas() {
		return managePortfolioDatas;
	}
	public void setManagePortfolioDatas(
			List<ManagePortfolioData> managePortfolioDatas) {
		this.managePortfolioDatas = managePortfolioDatas;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
	
	
}
