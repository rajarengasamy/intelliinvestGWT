package com.intelliinvest.web.bo;

import java.io.Serializable;

public interface IntelliInvestData extends Serializable{

}
