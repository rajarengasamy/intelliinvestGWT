package com.intelliinvest.web.bo;

import java.util.Date;
import java.util.List;

import com.intelliinvest.data.model.ManagePortfolioData;

public class PortfolioFormParameters {

	private String userId;
	private List<ManagePortfolioData> managePortfolioDatas;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public List<ManagePortfolioData> getManagePortfolioDatas() {
		return managePortfolioDatas;
	}
	public void setManagePortfolioDatas(
			List<ManagePortfolioData> managePortfolioDatas) {
		this.managePortfolioDatas = managePortfolioDatas;
	}
	
	
	
}
