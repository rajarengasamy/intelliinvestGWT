package com.intelliinvest.web.dao;

import java.util.ArrayList;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.dom4j.Node;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.intelliinvest.data.model.UserDetailData;
import com.intelliinvest.web.common.IntelliInvestStore;
import com.intelliinvest.web.common.IntelliinvestException;
import com.intelliinvest.web.util.EncryptUtil;
import com.intelliinvest.web.util.HibernateUtilCustom;
import com.intelliinvest.web.util.MailUtil;

public class UserDetailDAO {

	private static Logger logger = Logger.getLogger(UserDetailDAO.class);

	private static UserDetailDAO userDao;

	private static String MAIL_ID_EXISTS_QUERY = "SELECT MAIL FROM USER_DETAILS WHERE  MAIL=:mail";

	private static String MAIL_ID_FROM_USER_QUERY = "SELECT MAIL FROM USER_DETAILS WHERE  USER_ID=:userId";

	private static String LOGIN_QUERY = "SELECT USER_ID, USERNAME, PASSWORD, MAIL,PHONE, PLAN, USERTYPE, ACTIVE, ACTIVATION_CODE"
			+ ", CREATION_DATE, RENEWAL_DATE, EXPIRY_DATE, LAST_LOGIN_DATE, SEND_NOTIFICATION "
			+ "FROM USER_DETAILS WHERE MAIL=:mail and PASSWORD=:password";

	private static String USER_DETAIL_QUERY = "SELECT USER_ID, USERNAME, PASSWORD, MAIL,PHONE, PLAN, USERTYPE, ACTIVE, ACTIVATION_CODE"
			+ ", CREATION_DATE, RENEWAL_DATE, EXPIRY_DATE, LAST_LOGIN_DATE, SEND_NOTIFICATION  FROM USER_DETAILS WHERE MAIL=:mail";

	private static String REGISTER_QUERY = "INSERT INTO USER_DETAILS (USER_ID, USERNAME, MAIL,PHONE, PASSWORD, PLAN, USERTYPE, ACTIVE, ACTIVATION_CODE, CREATION_DATE, RENEWAL_DATE, EXPIRY_DATE, LAST_LOGIN_DATE, SEND_NOTIFICATION)"
			+ " VALUES (:userId, :username, :mail, :phone, :password, :plan, :userType, :active, :activationCode,"
			+ " :creationDate, :renewalDate, :expiryDate, :lastLoginDate, :sendNotification )";

	private static String UPDATE_QUERY = "UPDATE USER_DETAILS set PHONE=:phone, PASSWORD=:newPassword, SEND_NOTIFICATION=:sendNotification where MAIL=:mail and PASSWORD=:password";

	private static String UPDATE_LAST_LOGIN_DATE_QUERY = "UPDATE USER_DETAILS set LAST_LOGIN_DATE=:lastLoginDate where MAIL=:mail";

	private static String UPDATE_EXCEPT_PASSWORD_QUERY = "UPDATE USER_DETAILS set PHONE=:phone, SEND_NOTIFICATION=:sendNotification where MAIL=:mail";

	private static String ACTIVATION_QUERY = "UPDATE USER_DETAILS set ACTIVE='Y' where MAIL=:mail and ACTIVATION_CODE=:activationCode";

	private static String ADMIN_SELECT_QUERY = "SELECT USER_ID, USERNAME, PASSWORD, MAIL,PHONE, PLAN, USERTYPE, ACTIVE, ACTIVATION_CODE"
			+ ", CREATION_DATE, RENEWAL_DATE, EXPIRY_DATE, LAST_LOGIN_DATE, SEND_NOTIFICATION "
			+ " FROM USER_DETAILS";

	private static String ADMIN_UPDATE_QUERY = "UPDATE USER_DETAILS set USERNAME=:username, PASSWORD=:password, PHONE=:phone, PLAN=:plan,"
			+ " USERTYPE=:userType, ACTIVE=:active, RENEWAL_DATE=:renewalDate, EXPIRY_DATE=:expiryDate"
			+ " , SEND_NOTIFICATION=:sendNotification where MAIL=:mail";

	private static String ADMIN_DELETE_QUERY = "DELETE FROM USER_DETAILS where MAIL=:mail";

	private UserDetailDAO() {
		// CREATE Table USER_DETAILS (USER_ID varchar(25), USERNAME varchar(25),
		// MAIL varchar(50), PHONE varchar(20), PASSWORD varchar(100)
		// , PLAN varchar(20), USERTYPE varchar(10), ACTIVE varchar(2),
		// ACTIVATION_CODE varchar(20), CREATION_DATE DATE, RENEWAL_DATE DATE,
		// EXPIRY_DATE DATE
		// )
	}

	public static UserDetailDAO getInstance() {
		if (null == userDao) {
			synchronized (UserDetailDAO.class) {
				if (null == userDao) {
					userDao = new UserDetailDAO();
					logger.info("Initialised UserDao");
				}
			}
		}
		return userDao;
	}

	public String getMailIdFromUserId(String userId)
			throws IntelliinvestException {
		Session session = null;
		Transaction transaction = null;
		try {
			session = HibernateUtilCustom.getSession();
			transaction = session.beginTransaction();
			List<Object> userDetails = session
					.createSQLQuery(MAIL_ID_FROM_USER_QUERY)
					.setParameter("userId", userId).list();
			session.flush();
			transaction.commit();
			if (userDetails.size() >= 1) {
				return userDetails.get(0).toString();
			} else {
				return null;
			}

		} catch (Exception e) {
			transaction.rollback();
			if (null != session && session.isOpen()) {
				session.close();
			}
			throw new IntelliinvestException(
					"Exception while fetching the data for userid: " + userId
							+ " ||| exception:" + e.getMessage());
		} finally {
			if (null != session && session.isOpen()) {
				session.close();
			}
		}
	}

	public Boolean mailIdExists(String mail) throws IntelliinvestException {
		Session session = null;
		Transaction transaction = null;
		try {
			session = HibernateUtilCustom.getSession();
			transaction = session.beginTransaction();
			List<Object> userDetails = session
					.createSQLQuery(MAIL_ID_EXISTS_QUERY)
					.setParameter("mail", mail).list();
			session.flush();
			transaction.commit();
			if (userDetails.size() >= 1) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			transaction.rollback();
			if (null != session && session.isOpen()) {
				session.close();
			}

			throw new IntelliinvestException("Login exists for user " + mail
					+ " failed " + e.getMessage());
		} finally {
			if (null != session && session.isOpen()) {
				session.close();
			}

		}
	}

	@SuppressWarnings("unchecked")
	public UserDetailData login(String mail, String password)
			throws IntelliinvestException {
		UserDetailData userDetailData = new UserDetailData();
		Session session = null;
		Transaction transaction = null;
		boolean not_active_user = false;
		boolean no_user=false;
		try {
			session = HibernateUtilCustom.getSession();
			transaction = session.beginTransaction();
			logger.info("going to hit the query..............");
			List<UserDetailData> userDetails = session
					.createSQLQuery(LOGIN_QUERY)
					.addEntity(UserDetailData.class).setParameter("mail", mail)
					.setParameter("password", password).list();
			transaction.commit();
			logger.info(userDetails.size());
			if (userDetails.size() == 1) {
				logger.info("user found.....");
				if (userDetails.get(0).getActive().equals("Y")) {
					logger.info("Login for user "
							+ userDetails.get(0).getUsername() + " successful");
					updateLastLoginDate(mail);
					return userDetails.get(0);
				} else {
					//
					logger.info("user not active.........");
					not_active_user = true;
					throw new IntelliinvestException(
							"Please activate account before logging in. Check mail for more details.");
					//
				}
			} else {
				logger.info("Login for user " + mail + " failed");
				no_user=true;
				throw new IntelliinvestException(
						"Login for user "
								+ mail
								+ " failed. Please check user name and/or password entered");

			}
		} catch (Exception e) {

			if (null != session && session.isOpen()) {
				session.close();
			}
			if (not_active_user)
				throw e;
			else if(no_user)
				throw e;
			else{
			throw new IntelliinvestException(
					"Login for user "
							+ mail
							+ " failed due to system failure. It has been notified to Admin. Please try after some time || exception: "
							+ e.getMessage());
			}
		} finally {
			if (null != session && session.isOpen()) {
				session.close();
			}
		}
	}

	private void updateLastLoginDate(String mail) {
		Session session = null;
		Transaction transaction = null;
		try {
			session = HibernateUtilCustom.getSession();
			transaction = session.beginTransaction();
			session.createSQLQuery(UPDATE_LAST_LOGIN_DATE_QUERY)
					.setParameter("mail", mail)
					.setParameter("lastLoginDate", new Date()).executeUpdate();
			logger.info("Last Login Date updated for user with mail id " + mail
					+ " successful");
			session.flush();
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			if (null != session && session.isOpen()) {
				session.close();
			}
			logger.info("Error updating Last Login Date details for user with mail id "
					+ mail + " successful " + e.getMessage());
		} finally {
			if (null != session && session.isOpen()) {
				session.close();
			}
		}
	}

	@SuppressWarnings("unchecked")
	private UserDetailData getUserDetailFromMail(String mail)
			throws IntelliinvestException {
		Session session = null;
		Transaction transaction = null;
		UserDetailData userDetailData = null;
		try {
			session = HibernateUtilCustom.getSession();
			transaction = session.beginTransaction();
			List<UserDetailData> userDetails = session
					.createSQLQuery(USER_DETAIL_QUERY)
					.addEntity(UserDetailData.class).setParameter("mail", mail)
					.list();
			session.flush();
			transaction.commit();
			if (userDetails.size() == 1) {
				userDetailData = userDetails.get(0);
			}
		} catch (Exception e) {

			transaction.rollback();
			if (null != session && session.isOpen()) {
				session.close();
			}
			throw new IntelliinvestException(
					"Error while getting details for user from mailId "
							+ e.getMessage());

		} finally {
			if (null != session && session.isOpen()) {
				session.close();
			}
		}
		return userDetailData;
	}

	public String forgotPassword(String mail) throws Exception {
		boolean password_send_failure = false;
		try {
			UserDetailData userDetailData = getUserDetailFromMail(mail);
			if (null != userDetailData) {
				Long time = System.currentTimeMillis();
				String randomText = "INI"
						+ time.toString().substring(
								time.toString().length() - 5);
				saveProfile(userDetailData.getUsername(),
						userDetailData.getMail(), userDetailData.getPhone(),
						userDetailData.getPassword(),
						EncryptUtil.encrypt(randomText),
						userDetailData.getSendNotification());
				logger.info("Mail sent to your maild id registered with us");
				if (MailUtil.sendMail(IntelliInvestStore.properties
						.getProperty("smtp.host"),
						IntelliInvestStore.properties.getProperty("mail.from"),
						IntelliInvestStore.properties
								.getProperty("mail.password"),
						new String[] { mail },
						"Password reset from IntelliInvest",
						"Hi,\n Your password has been reset to " + randomText)) {
					logger.info("Mail sent to user with mail id " + mail + "");
					return "New Password sent to your registered maild id";
				} else {
					logger.error("Error sending to user with mail id " + mail
							+ "");
					password_send_failure = true;
					throw new IntelliinvestException(
							"Problem sending activation mail to your account. Please contact admin for further support");
				}

			} else {
				logger.info("Mail not sent to user with mail id " + mail
						+ " because Username does not exists");
				password_send_failure = true;
				throw new IntelliinvestException("Username does not exists");
			}
		} catch (Exception e) {

			if (password_send_failure)
				throw e;
			throw new IntelliinvestException(
					"Error while sending mail for forgot password failed "
							+ e.getMessage());
		}
	}

	public UserDetailData register(String userName, String mail, String phone,
			String password, Boolean sendNotification)
			throws IntelliinvestException {
		UserDetailData userDetail = new UserDetailData();
		if (mailIdExists(mail)) {
			throw new IntelliinvestException("Mail Id already exists");
		}
		Session session = null;
		Transaction transaction = null;
		try {
			session = HibernateUtilCustom.getSession();
			transaction = session.beginTransaction();
			Long time = System.currentTimeMillis();
			String randomText = "ACT"
					+ time.toString().substring(time.toString().length() - 5);
			String userId = "USER" /*
									 * +
									 * KeyGeneratorDao.getInstance().generateKey
									 * ("userId", session)
									 */;
			Date currentDate = getCurrentDate();
			Date expiryDate = addDaysToDate(currentDate, new Integer(
					IntelliInvestStore.properties.get("trail.period")
							.toString()));

			session.createSQLQuery(REGISTER_QUERY)
					.setParameter("userId", userId)
					.setParameter("username", userName)
					.setParameter("mail", mail).setParameter("phone", phone)
					.setParameter("password", password)
					.setParameter("plan", "Default_10")
					.setParameter("userType", "User")
					.setParameter("active", "N")
					.setParameter("activationCode", randomText)
					.setParameter("creationDate", currentDate)
					.setParameter("renewalDate", currentDate)
					.setParameter("expiryDate", expiryDate)
					.setParameter("lastLoginDate", new Date())
					.setParameter("sendNotification", sendNotification)
					.executeUpdate();
			logger.info("Registration for user " + userName + " with mail id "
					+ mail + " successful");
			logger.info("Sending activation mail for user " + mail);
			MailUtil.sendMail(
					IntelliInvestStore.properties.getProperty("smtp.host"),
					IntelliInvestStore.properties.getProperty("mail.from"),
					IntelliInvestStore.properties.getProperty("mail.password"),
					new String[] { mail },
					"Activation of IntelliInvest Account",
					"Hi "
							+ userName
							+ ",<br>To activate your account please click below link<br>http://"
							+ IntelliInvestStore.properties
									.getProperty("context.url")
							+ "/intelliinvest/login?mailId=" + mail
							+ "&activationCode=" + randomText
							+ "<br>Regards,<br>IntelliInvest Team.");
			session.flush();
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			if (null != session && session.isOpen()) {
				session.close();
			}

			throw new IntelliinvestException("Registration failed for user "
					+ userName + " with mail id " + mail + " " + e.getMessage());
		} finally {
			if (null != session && session.isOpen()) {
				session.close();
			}
		}
		return userDetail;
	}

	private Date getCurrentDate() {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		cal.set(Calendar.AM_PM, Calendar.AM);
		return cal.getTime();
	}

	private Date addDaysToDate(Date date, int days) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, days);
		return cal.getTime();
	}

	public Boolean activateAccount(String mail, String activationCode)
			throws IntelliinvestException {
		Session session = null;
		Transaction transaction = null;
		try {
			session = HibernateUtilCustom.getSession();
			transaction = session.beginTransaction();
			int updatedRows = session.createSQLQuery(ACTIVATION_QUERY)
					.setParameter("mail", mail)
					.setParameter("activationCode", activationCode)
					.executeUpdate();
			session.flush();
			transaction.commit();
			if (updatedRows == 1) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			transaction.rollback();
			if (null != session && session.isOpen()) {
				session.close();
			}

			throw new IntelliinvestException("Error activating for user "
					+ mail + " with activation code " + activationCode + " "
					+ e.getMessage());
		} finally {
			if (null != session && session.isOpen()) {
				session.close();
			}
		}
	}

	public UserDetailData saveProfileExceptPassword(String userName,
			String mail, String phone, String password, Boolean sendNotification)
			throws IntelliinvestException {
		Session session = null;
		Transaction transaction = null;
		try {
			session = HibernateUtilCustom.getSession();
			transaction = session.beginTransaction();

			session.createSQLQuery(UPDATE_EXCEPT_PASSWORD_QUERY)
					.setParameter("mail", mail).setParameter("phone", phone)
					.setParameter("sendNotification", sendNotification)
					.executeUpdate();
			logger.info("Updated details for user " + userName
					+ " with mail id " + mail + " successful");
			session.flush();
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			if (null != session && session.isOpen()) {
				session.close();
			}
			throw new IntelliinvestException("Error updating details for user "
					+ userName + " with mail id " + mail + " " + e.getMessage());

		} finally {
			if (null != session && session.isOpen()) {
				session.close();
			}
		}
		return getUserDetailFromMail(mail);
	}

	public UserDetailData saveProfile(String userName, String mail,
			String phone, String oldPassword, String newPassword,
			Boolean sendNotification) throws IntelliinvestException {
		logger.info("Updating details for user " + userName + " with mail id "
				+ mail + " Phone " + phone + " oldPassword " + oldPassword
				+ " new password " + newPassword);
		if (null != newPassword && "".equals(newPassword.trim())) {
			return saveProfileExceptPassword(userName, mail, phone,
					oldPassword, sendNotification);
		}
		Session session = null;
		Transaction transaction = null;
		int recordUpdated=0;
		try {
			session = HibernateUtilCustom.getSession();
			transaction = session.beginTransaction();
			recordUpdated = session.createSQLQuery(UPDATE_QUERY).setParameter("mail", mail)
					.setParameter("phone", phone)
					.setParameter("password", oldPassword)
					.setParameter("newPassword", newPassword)
					.setParameter("sendNotification", sendNotification)
					.executeUpdate();
			logger.info("Updated details for user " + userName
					+ " with mail id " + mail + " successful");
			session.flush();
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			if (null != session && session.isOpen()) {
				session.close();
			}

			throw new IntelliinvestException("Error updating details for user "
					+ userName + " with mail id " + mail + " successful "
					+ e.getMessage());
		} finally {
			if (null != session && session.isOpen()) {
				session.close();
			}
		}
		
		if(recordUpdated==0){
			throw new IntelliinvestException("No user found with given details...");
		}
		return getUserDetailFromMail(mail);
	}

	@SuppressWarnings("unchecked")
	public List<UserDetailData> getUserDetails() throws IntelliinvestException {

		Session session = null;
		Transaction transaction = null;
		List<UserDetailData> userDetailDatas = new ArrayList<UserDetailData>();
		try {
			logger.info("---------------Query----------- " + ADMIN_SELECT_QUERY);
			session = HibernateUtilCustom.getSession();
			transaction = session.beginTransaction();
			logger.info("--------After begin transaction------------");
			userDetailDatas = session.createSQLQuery(ADMIN_SELECT_QUERY)
					.addEntity(UserDetailData.class).list();
			logger.info("Users Count:" + userDetailDatas.size());
			// session.flush();
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null)
				transaction.rollback();
			e.printStackTrace();
			throw new IntelliinvestException(
					"Some Exception occured while fetching the userdetails from DB "
							+ e.getMessage());
		} finally {
			HibernateUtilCustom.closeSession();
		}
		return userDetailDatas;

	}

	//
	// @SuppressWarnings("unchecked")
	// public List<UserDetailData> addUserDetail(String user,
	// List<UserDetailData> userDetailDatas) {
	// Session session = null;
	// Transaction transaction = null;
	// try {
	// session = HibernateUtil.getSession();
	// transaction = session.beginTransaction();
	// for (UserDetailData userDetailData : userDetailDatas) {
	// logger.info("Inserting " + userDetailData);
	// if (null != user) {
	// register(userDetailData.getUsername(),
	// userDetailData.getMail(),
	// userDetailData.getPhone(),
	// userDetailData.getPassword(),
	// userDetailData.getSendNotification());
	// List<UserDetailData> userDetails = session
	// .createSQLQuery(USER_DETAIL_QUERY)
	// .addEntity(UserDetailData.class)
	// .setParameter("mail", userDetailData.getMail())
	// .list();
	// if (userDetails.size() == 1) {
	// userDetailData = userDetails.get(0);
	// }
	// }
	//
	// }
	// session.flush();
	// transaction.commit();
	// } catch (Exception e) {
	// transaction.rollback();
	// if (null != session && session.isOpen()) {
	// session.close();
	// }
	// logger.info("Insertion failed " + e.getMessage());
	// return new ArrayList<UserDetailData>();
	// } finally {
	// if (null != session && session.isOpen()) {
	// session.close();
	// }
	// }
	// return userDetailDatas;
	// }
	//
	// public List<UserDetailData> updateUserDetail(String user,
	// List<UserDetailData> userDetailsData) {
	// Session session = null;
	// Transaction transaction = null;
	// try {
	// session = HibernateUtil.getSession();
	// transaction = session.beginTransaction();
	// int updatedRecords = 0;
	// for (UserDetailData userDetailData : userDetailsData) {
	// if (null != user) {
	// logger.info("Update " + userDetailData);
	// int updatedRecord = session
	// .createSQLQuery(ADMIN_UPDATE_QUERY)
	// .setParameter("username",
	// userDetailData.getUsername())
	// .setParameter("password",
	// userDetailData.getPassword())
	// .setParameter("phone", userDetailData.getPhone())
	// .setParameter("plan", userDetailData.getPlan())
	// .setParameter("userType",
	// userDetailData.getUserType())
	// .setParameter("active", userDetailData.getActive())
	// .setParameter("mail", userDetailData.getMail())
	// .setParameter("renewalDate",
	// userDetailData.getRenewalDate())
	// .setParameter("expiryDate",
	// userDetailData.getExpiryDate())
	// .setParameter("sendNotification",
	// userDetailData.getSendNotification())
	// .executeUpdate();
	// updatedRecords = updatedRecords + updatedRecord;
	// }
	// }
	// logger.info("Updated " + updatedRecords + " successfully");
	// session.flush();
	// transaction.commit();
	// } catch (Exception e) {
	// transaction.rollback();
	// if (null != session && session.isOpen()) {
	// session.close();
	// }
	// logger.info("Updation failed " + e.getMessage());
	// return new ArrayList<UserDetailData>();
	// } finally {
	// if (null != session && session.isOpen()) {
	// session.close();
	// }
	// }
	// return userDetailsData;
	// }
	//
	public boolean removeUserDetail(String mail) throws IntelliinvestException {

		Session session = null;
		Transaction transaction = null;
		int deletedRecords = 0;
		try {
			session = HibernateUtilCustom.getSession();
			transaction = session.beginTransaction();

			int deletedRecord = session.createSQLQuery(ADMIN_DELETE_QUERY)
					.setParameter("mail", mail).executeUpdate();
			deletedRecords = deletedRecords + deletedRecord;
			logger.info("Deleted " + deletedRecords + " successfully");
			session.flush();
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			if (null != session && session.isOpen()) {
				session.close();
			}
			logger.info("Updation failed " + e.getMessage());
			throw new IntelliinvestException(
					"Exception occured while db operation: " + e.getMessage());
		} finally {
			if (null != session && session.isOpen()) {
				session.close();
			}
		}

		if (deletedRecords == 0)
			return false;
		return true;
	}

}
