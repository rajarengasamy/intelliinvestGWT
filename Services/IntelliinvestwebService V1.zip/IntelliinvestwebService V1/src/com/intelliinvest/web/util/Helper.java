package com.intelliinvest.web.util;

import java.util.List;



public class Helper {

	public boolean isNotNullOrNonEmpty(String str) {
		if (str != null & str.trim().length() > 0)
			return true;
		else
			return false;
	}

	public boolean isNotNullOrNonEmpty(List list) {
		if (list != null && list.size() > 0)
			return true;
		else
			return false;
	}

//	public boolean isNotNullOrNonEmpty(
//			List<ManagePortfolioData> managePortfolioDatas) {
//		// TODO Auto-generated method stub
//		return false;
//	}

}
