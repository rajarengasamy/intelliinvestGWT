package com.intelliinvest.web.util;

import java.util.ArrayList;
import java.util.List;

import com.intelliinvest.data.model.UserDetailData;
import com.intelliinvest.web.bo.UserDetailDataResponse;
import com.intelliinvest.web.bo.UserDetailFormParameters;

public class Converter {

	public com.intelliinvest.web.bo.UserDetailDataResponse convertUserDetailData(
			UserDetailData userDetailData) {

		com.intelliinvest.web.bo.UserDetailDataResponse userDeDataBO = new com.intelliinvest.web.bo.UserDetailDataResponse();

		userDeDataBO.setActivationCode(userDetailData.getActivationCode());
		userDeDataBO.setActive(userDetailData.getActive());
		userDeDataBO.setCreationDate(userDetailData.getCreationDate());
		userDeDataBO.setExpiryDate(userDetailData.getExpiryDate());
		userDeDataBO.setLastLoginDate(userDetailData.getLastLoginDate());
		userDeDataBO.setMail(userDetailData.getMail());
		userDeDataBO.setPassword(userDetailData.getPassword());
		userDeDataBO.setPhone(userDetailData.getPhone());

		userDeDataBO.setPlan(userDetailData.getPlan());
		userDeDataBO.setRenewalDate(userDetailData.getRenewalDate());
		userDeDataBO.setSendNotification(userDetailData.getSendNotification());
		userDeDataBO.setUserId(userDetailData.getUserId());

		userDeDataBO.setUsername(userDetailData.getUsername());
		userDeDataBO.setUserType(userDetailData.getUserType());

		return userDeDataBO;
	}

	public UserDetailData convertUserDetailData(
			com.intelliinvest.web.bo.UserDetailDataResponse userDetailDataBO) {
		UserDetailData userDetailData = new UserDetailData();

		return userDetailData;
	}

	public List<com.intelliinvest.web.bo.UserDetailDataResponse> convertUsersList(
			List<UserDetailData> userDetails) {

		List<com.intelliinvest.web.bo.UserDetailDataResponse> userDetailsRes = new ArrayList<>();
		if (userDetails != null) {
			for (UserDetailData userDetailData : userDetails) {
				userDetailsRes.add(convertUserDetailData(userDetailData));
			}
		}
		return userDetailsRes;
	}

	public UserDetailData getUserDetailData(
			UserDetailFormParameters userDetailFormParameter) {

		UserDetailData userDetailDataModel = new UserDetailData();

		userDetailDataModel.setMail(userDetailFormParameter.getMail());
		userDetailDataModel.setPassword(userDetailFormParameter.getPassword());
		userDetailDataModel.setPhone(userDetailFormParameter.getPhone());

		if (userDetailFormParameter.getSendNotification() != null) {
			try {
				userDetailDataModel.setSendNotification(Boolean
						.parseBoolean(userDetailFormParameter
								.getSendNotification()));
			} catch (NumberFormatException e) {
				userDetailDataModel.setSendNotification(false);
			}
		} else
			userDetailDataModel.setSendNotification(false);
		userDetailDataModel.setUserId(userDetailFormParameter.getUserId());

		userDetailDataModel.setUsername(userDetailFormParameter.getUsername());

		return userDetailDataModel;
	}

	public UserDetailDataResponse getUserDetailResponse(
			UserDetailData userDetailData) {
		UserDetailDataResponse userDetailDataResponse = new UserDetailDataResponse();
		userDetailDataResponse.setMail(userDetailData.getMail());
		userDetailDataResponse.setUsername(userDetailData.getUsername());
		userDetailDataResponse.setSendNotification(userDetailData
				.getSendNotification());
		userDetailDataResponse.setPhone(userDetailData.getPhone());
		// userDetailDataResponse.setPassword(userDetailData.getPassword());
		userDetailDataResponse.setUserId(userDetailData.getUserId());

		return userDetailDataResponse;
	}

}
