package com.intelliinvest.web.controllers;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.intelliinvest.data.model.ManagePortfolioData;
import com.intelliinvest.data.model.UserDetailData;
import com.intelliinvest.web.bo.PortfolioFormParameters;
import com.intelliinvest.web.bo.PortfolioResponse;
import com.intelliinvest.web.bo.UserDetailDataResponse;
import com.intelliinvest.web.bo.UserDetailFormParameters;
import com.intelliinvest.web.common.CommonConstParams;
import com.intelliinvest.web.common.IntelliinvestException;
import com.intelliinvest.web.dao.ManagePortfolioDao;
import com.intelliinvest.web.dao.UserDetailDAO;
import com.intelliinvest.web.util.Converter;
import com.intelliinvest.web.util.EncryptUtil;
import com.intelliinvest.web.util.Helper;

@Controller
public class ManagePortfolioController {

	@Autowired
	private ManagePortfolioDao managePortfolioDAO;

	@Autowired
	private Converter converter;

	@Autowired
	private Helper helper;

	private static Logger logger = Logger.getLogger(ManagePortfolioController.class);


	@RequestMapping(method = RequestMethod.POST, value = "/portfolio/update")
	public @ResponseBody
	PortfolioResponse updatePortfolio(
			@RequestBody PortfolioFormParameters portfolioFormParameters) {

		PortfolioResponse portfolioResponse = new PortfolioResponse();
		
		String userId= portfolioFormParameters.getUserId();
		List<ManagePortfolioData> managePortfolioDatas =  portfolioFormParameters.getManagePortfolioDatas();
		
		List<ManagePortfolioData> responseData=null;
		String errorMsg = CommonConstParams.ERROR_MSG_DEFAULT;
		if (helper.isNotNullOrNonEmpty(userId) && helper.isNotNullOrNonEmpty(managePortfolioDatas)) {
			 try {
				 responseData = managePortfolioDAO.updateManagePortfolioData(userId, managePortfolioDatas);
				 
			} catch (Exception e) {
				e.printStackTrace();
				errorMsg =e.getMessage();
			}

		}
		portfolioResponse.setUserId(userId);
		if (responseData != null) {
//			portfolioResponse.setManagePortfolioDatas(responseData);
			portfolioResponse.setSuccess(true);
		} else {
			portfolioResponse.setSuccess(false);
			portfolioResponse.setMessage(errorMsg);
		}

		return portfolioResponse;
	}


	@RequestMapping(method = RequestMethod.POST, value = "/portfolio/add")
	public @ResponseBody
	PortfolioResponse addPortfolio(
			@RequestBody PortfolioFormParameters portfolioFormParameters) {

		PortfolioResponse portfolioResponse = new PortfolioResponse();
		
		String userId= portfolioFormParameters.getUserId();
		List<ManagePortfolioData> managePortfolioDatas =  portfolioFormParameters.getManagePortfolioDatas();
		
		List<ManagePortfolioData> responseData=null;
		String errorMsg = CommonConstParams.ERROR_MSG_DEFAULT;
		logger.info(portfolioFormParameters.getManagePortfolioDatas().size());
		logger.info(portfolioFormParameters.getManagePortfolioDatas());
		if (helper.isNotNullOrNonEmpty(userId) && helper.isNotNullOrNonEmpty(managePortfolioDatas)) {
			 try {
				 responseData = managePortfolioDAO.addManagePortfolioData(userId, managePortfolioDatas);
				 
			} catch (Exception e) {
				e.printStackTrace();
				errorMsg =e.getMessage();
			}

		}
		portfolioResponse.setUserId(userId);
		if (responseData != null) {
//			portfolioResponse.setManagePortfolioDatas(responseData);
			portfolioResponse.setSuccess(true);
		} else {
			portfolioResponse.setSuccess(false);
			portfolioResponse.setUserId(userId);
			portfolioResponse.setMessage(errorMsg);
		}

		return portfolioResponse;
	}
	

	@RequestMapping(method = RequestMethod.POST, value = "/portfolio/get")
	public @ResponseBody
	PortfolioResponse getPortfolio(
			@RequestBody PortfolioFormParameters portfolioFormParameters) {

		PortfolioResponse portfolioResponse = new PortfolioResponse();
		
		String userId= portfolioFormParameters.getUserId();
		List<ManagePortfolioData> managePortfolioDatas =  portfolioResponse.getManagePortfolioDatas();
		
		List<ManagePortfolioData> responseData=null;
		String errorMsg = CommonConstParams.ERROR_MSG_DEFAULT;
		if (helper.isNotNullOrNonEmpty(userId)) {
			 try {
				 responseData = managePortfolioDAO.getManagePortfolioData(userId);
				 
			} catch (Exception e) {
				e.printStackTrace();
				errorMsg =e.getMessage();
			}

		}
		portfolioResponse.setUserId(userId);
		if (responseData != null) {
			
			portfolioResponse.setManagePortfolioDatas(responseData);
			portfolioResponse.setSuccess(true);
		} else {
			portfolioResponse.setSuccess(false);
			portfolioResponse.setMessage(errorMsg);
		}

		return portfolioResponse;
	}
	

	@RequestMapping(method = RequestMethod.POST, value = "/portfolio/getData")
	public @ResponseBody
	PortfolioResponse getManagePortfolioData(
			@RequestBody PortfolioFormParameters portfolioFormParameters) {

		PortfolioResponse portfolioResponse = new PortfolioResponse();
		
		String userId= portfolioFormParameters.getUserId();
		List<ManagePortfolioData> managePortfolioDatas =  portfolioResponse.getManagePortfolioDatas();
		
		List<ManagePortfolioData> responseData=null;
		String errorMsg = CommonConstParams.ERROR_MSG_DEFAULT;
		if (helper.isNotNullOrNonEmpty(userId) && helper.isNotNullOrNonEmpty(managePortfolioDatas)) {
			 try {
				 responseData = managePortfolioDAO.getManagePortfolioData(userId, managePortfolioDatas);
				 
			} catch (Exception e) {
				e.printStackTrace();
				errorMsg =e.getMessage();
			}

		}
		portfolioResponse.setUserId(userId);
		if (responseData != null) {
			portfolioResponse.setManagePortfolioDatas(responseData);
			portfolioResponse.setSuccess(true);
		} else {
			portfolioResponse.setSuccess(false);
			portfolioResponse.setMessage(errorMsg);
		}

		return portfolioResponse;
	}
}
