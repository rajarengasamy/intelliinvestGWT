package com.intelliinvest.web.controllers;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.CommonAnnotationBeanPostProcessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.intelliinvest.data.model.UserDetailData;

import com.intelliinvest.web.bo.UserDetailDataResponse;
import com.intelliinvest.web.bo.UserDetailFormParameters;
import com.intelliinvest.web.common.CommonConstParams;
import com.intelliinvest.web.common.IntelliinvestException;

import com.intelliinvest.web.dao.UserDetailDAO;

import com.intelliinvest.web.util.Converter;
import com.intelliinvest.web.util.EncryptUtil;
import com.intelliinvest.web.util.Helper;

@Controller
public class UserDetailController {

	@Autowired
	private UserDetailDAO userDetailDAO;

	@Autowired
	private Converter converter;

	@Autowired
	private Helper helper;

	private static Logger logger = Logger.getLogger(UserDetailController.class);

	public UserDetailDAO getUserDetailDAO() {
		return userDetailDAO;
	}

	public void setUserDetailDAO(UserDetailDAO userDetailDAO) {
		this.userDetailDAO = userDetailDAO;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/getEmail")
	public @ResponseBody
	UserDetailDataResponse getEmailFromUserID(
			@RequestBody com.intelliinvest.web.bo.UserDetailFormParameters userDetailFormParameters) {

		UserDetailDataResponse userDetailDataResponse = new UserDetailDataResponse();
		if (helper.isNotNullOrNonEmpty(userDetailFormParameters.getUserId())) {
			String userId = userDetailFormParameters.getUserId();
			String mailID = null;
			String errorMsg = CommonConstParams.ERROR_MSG_DEFAULT;
			try {
				mailID = userDetailDAO.getMailIdFromUserId(userId);
			} catch (IntelliinvestException e) {
				e.printStackTrace();
				errorMsg = e.getMessage();
			}

			if (mailID != null) {
				userDetailDataResponse.setMail(mailID);
				userDetailDataResponse.setUserId(userId);
				userDetailDataResponse.setSuccess(true);
			} else {
				userDetailDataResponse.setUserId(userId);
				userDetailDataResponse.setSuccess(false);
				userDetailDataResponse.setMessage(errorMsg);
			}

		}

		return userDetailDataResponse;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/user/update")
	public @ResponseBody
	UserDetailDataResponse updateUserDetail(
			@RequestBody UserDetailFormParameters userDetailFormParameters) {

		UserDetailDataResponse userDetailDataResponse = new UserDetailDataResponse();
		UserDetailData userDetailData = null;
		String userName = userDetailFormParameters.getUsername();
		String mail = userDetailFormParameters.getMail();
		String oldPassword=userDetailFormParameters.getOldPassword();
		String password = userDetailFormParameters.getPassword();
		String phone = userDetailFormParameters.getPhone();
		String userId = userDetailFormParameters.getUserId();
		String sendNotification = userDetailFormParameters
				.getSendNotification();
		String errorMsg = CommonConstParams.ERROR_MSG_DEFAULT;
		if (helper.isNotNullOrNonEmpty(password) && helper.isNotNullOrNonEmpty(oldPassword)) {
			 try {
				userDetailData = userDetailDAO.saveProfile(userName, mail, phone, EncryptUtil.encrypt(oldPassword),
				 EncryptUtil.encrypt(password), Boolean.parseBoolean(sendNotification));
			} catch (Exception e) {
				e.printStackTrace();
				errorMsg =e.getMessage();
			}

		} else {

			logger.info("in else case, where password is null or empty...");
			try {
				userDetailData = userDetailDAO.saveProfileExceptPassword(
						userName, mail, phone, password,
						Boolean.valueOf(sendNotification));
				logger.info("after update user...");
			} catch (Exception e) {
				e.printStackTrace();
				errorMsg = e.getMessage();
			}
		}
		if (userDetailData != null) {
			userDetailDataResponse = converter
					.getUserDetailResponse(userDetailData);
			userDetailDataResponse.setSuccess(true);
		} else {
			userDetailDataResponse.setSuccess(false);
			userDetailDataResponse.setMessage(errorMsg);
		}

		return userDetailDataResponse;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/user/login")
	public @ResponseBody
	UserDetailDataResponse login(
			@RequestBody UserDetailFormParameters userDetailFormParameters) {

		UserDetailDataResponse userDetailDataResponse = new UserDetailDataResponse();
		UserDetailData userDetailData = null;

		String mail = userDetailFormParameters.getMail();
		String password = userDetailFormParameters.getPassword();

		String errorMsg = CommonConstParams.ERROR_MSG_DEFAULT;

		if (helper.isNotNullOrNonEmpty(mail)
				&& helper.isNotNullOrNonEmpty(password)) {
			logger.info("in else case, where password is null or empty...");
			try {
				userDetailData = userDetailDAO.login(mail, EncryptUtil.encrypt(password));
				logger.info("after login user...");
			} catch (Exception e) {
				e.printStackTrace();
				errorMsg = e.getMessage();
			}
		}
		if (userDetailData != null) {
			userDetailDataResponse = converter
					.getUserDetailResponse(userDetailData);
			userDetailDataResponse.setSuccess(true);
		} else {
			userDetailDataResponse.setSuccess(false);
			userDetailDataResponse.setMessage(errorMsg);
		}

		return userDetailDataResponse;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/user/activate")
	public @ResponseBody
	UserDetailDataResponse activateUser(
			@RequestBody UserDetailFormParameters userDetailFormParameters) {

		UserDetailDataResponse userDetailDataResponse = new UserDetailDataResponse();
		Boolean response = false;

		String mail = userDetailFormParameters.getMail();
		String activationCode = userDetailFormParameters.getActivationCode();

		String errorMsg = CommonConstParams.ERROR_MSG_DEFAULT;

		if (helper.isNotNullOrNonEmpty(mail)
				&& helper.isNotNullOrNonEmpty(activationCode)) {
			logger.info("in else case, where password is null or empty...");
			try {
				response = userDetailDAO.activateAccount(mail, activationCode);
				logger.info("after login user...");
			} catch (Exception e) {
				e.printStackTrace();
				errorMsg = e.getMessage();
			}
		}
		if (response) {
			userDetailDataResponse.setSuccess(true);
			userDetailDataResponse
					.setMessage("Account has been activated successfully...");
		} else {
			userDetailDataResponse.setSuccess(false);
			userDetailDataResponse.setMessage(errorMsg);
		}

		return userDetailDataResponse;
	}

	

	@RequestMapping(method = RequestMethod.POST, value = "/user/forgotPassword")
	public @ResponseBody
	UserDetailDataResponse forgotPassword(
			@RequestBody UserDetailFormParameters userDetailFormParameters) {

		UserDetailDataResponse userDetailDataResponse = new UserDetailDataResponse();
		String response = null;

		String mail = userDetailFormParameters.getMail();
		
		String errorMsg = CommonConstParams.ERROR_MSG_DEFAULT;

		if (helper.isNotNullOrNonEmpty(mail)
				) {
			logger.info("in else case, where password is null or empty...");
			try {
				response = userDetailDAO.forgotPassword(mail);
				logger.info("after login user...");
			} catch (Exception e) {
				e.printStackTrace();
				errorMsg = e.getMessage();
			}
		}
		if (response!=null) {	
			userDetailDataResponse.setSuccess(true);
			userDetailDataResponse
					.setMessage(response);
		} else {
			userDetailDataResponse.setSuccess(false);
			userDetailDataResponse.setMessage(errorMsg);
		}

		return userDetailDataResponse;
	}
	
	//
	@RequestMapping(method = RequestMethod.POST, value = "/user/register")
	public @ResponseBody
	UserDetailDataResponse registerUser(
			@RequestBody com.intelliinvest.web.bo.UserDetailFormParameters userDetailFormParameters) {
		UserDetailDataResponse userDetailDataResponse = new UserDetailDataResponse();
		String errorMsg = CommonConstParams.ERROR_MSG_DEFAULT;

		String userName = userDetailFormParameters.getUsername();
		String password = userDetailFormParameters.getPassword();
		String mail = userDetailFormParameters.getMail();
		String phone = userDetailFormParameters.getPhone();
		String sendNotification = userDetailFormParameters
				.getSendNotification();

		UserDetailData userDetailData = null;

		try {
			if (helper.isNotNullOrNonEmpty(userName)
					&& helper.isNotNullOrNonEmpty(password)
					&& helper.isNotNullOrNonEmpty(mail)
					&& helper.isNotNullOrNonEmpty(phone)
					&& helper.isNotNullOrNonEmpty(sendNotification + "")) {
				userDetailData = userDetailDAO.register(userName, mail, phone,
						EncryptUtil.encrypt(password), Boolean.valueOf(sendNotification));
			}
		} catch (Exception e) {
			e.printStackTrace();
			errorMsg = e.getMessage();
		}

		if (userDetailData != null) {
			userDetailDataResponse = converter
					.getUserDetailResponse(userDetailData);
			userDetailDataResponse.setSuccess(true);
			userDetailDataResponse
					.setMessage("Registration for user "
							+ userName
							+ " with mail id "
							+ mail
							+ " successful. \n Please activate your account by clicking link in your activation mail.");
		} else {
			userDetailDataResponse.setSuccess(false);
			userDetailDataResponse.setMessage(errorMsg);
		}

		return userDetailDataResponse;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/users")
	public @ResponseBody
	List<com.intelliinvest.web.bo.UserDetailDataResponse> getUsers() {
		String errorMsg = CommonConstParams.ERROR_MSG_DEFAULT;
		List<UserDetailData> userDetails = null;
		try {
			userDetails = userDetailDAO.getUserDetails();
		} catch (IntelliinvestException e) {
			errorMsg = e.getMessage();
		}
		if (userDetails != null) {
			return converter.convertUsersList(userDetails);
		} else {
			List<UserDetailDataResponse> list = new ArrayList<>();
			UserDetailDataResponse userDetailDataResponse = new UserDetailDataResponse();
			userDetailDataResponse.setSuccess(false);
			userDetailDataResponse.setMessage(errorMsg);
			list.add(userDetailDataResponse);
			return list;
		}

	}

	@RequestMapping(method = RequestMethod.POST, value = "/user/remove")
	public @ResponseBody
	UserDetailDataResponse removeUser(
			@RequestBody com.intelliinvest.web.bo.UserDetailFormParameters userDetailFormParameters) {
		String errorMsg = CommonConstParams.ERROR_MSG_DEFAULT;
		String mail = userDetailFormParameters.getMail();
		UserDetailDataResponse userDetailDataResponse = new UserDetailDataResponse();
		boolean response = false;
		if (helper.isNotNullOrNonEmpty(mail)) {
			try {
				response = userDetailDAO.removeUserDetail(mail);
			} catch (IntelliinvestException e) {
				e.printStackTrace();
				errorMsg = e.getMessage();
			}
		}

		if (response) {
			userDetailDataResponse.setSuccess(true);
			userDetailDataResponse.setMail(mail);
		} else {
			userDetailDataResponse.setMail(mail);
			userDetailDataResponse.setSuccess(false);
			userDetailDataResponse.setMessage(errorMsg);
		}

		return userDetailDataResponse;

	}

}
